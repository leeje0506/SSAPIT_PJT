CREATE DATABASE ssafit;

USE ssafit;

CREATE TABLE Video(
	youtubeId VARCHAR(50) PRIMARY KEY NOT NULL,
    title VARCHAR(50) NOT NULL,
    fitPartName VARCHAR(20) NOT NULL,
    channelName VARCHAR(20) NOT NULL,
    url VARCHAR(100) NOT NULL,
    viewCnt LONG NOT NULL
) ENGINE = InnoDB;

CREATE TABLE mem (
	id VARCHAR(40) NOT NULL PRIMARY KEY,
    pw VARCHAR(40) NOT NULL,
    userName VARCHAR(40) NOT NULL,
    email VARCHAR(40)
) ENGINE = InnoDB;

CREATE TABLE Review(
	Id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    title VARCHAR(40) NOT NULL,
    writerId VARCHAR(40) NOT NULL,
    content LONGTEXT NOT NULL,
    regDate DATETIME NOT NULL,
	youtubeId VARCHAR(50) NOT NULL,
    viewCnt LONG NOT NULL,
    FOREIGN KEY (writerId) REFERENCES mem(id),
    FOREIGN KEY (youtubeId) REFERENCES Video (youtubeId)
) ENGINE = InnoDB;

INSERT INTO Video
VALUES ("gMaB-fG4u4g", "전신 다이어트 최고의 운동 [칼소폭 찐 핵핵매운맛]", "전신", "ThankyouBUBU", "https://www.youtube.com/embed/gMaB-fG4u4g", 0),
("swRNeYw1JkY", "하루 15분! 전신 칼로리 불태우는 다이어트 운동", "전신", "ThankyouBUBU", "https://www.youtube.com/embed/swRNeYw1JkY", 0),
("54tTYO-vU2E", "상체 다이어트 최고의 운동 BEST [팔뚝살/겨드랑이살/등살/가슴어깨라인]", "상체", "ThankreviewreviewyouBUBU", "https://www.youtube.com/embed/54tTYO-vU2E", 0);

INSERT INTO mem
VALUES ('ssafy1', 'ssafy1', '박민아', 'ssafy1@ssafy.com'),
('ssafy2', 'ssafy2', '이지은', 'ssafy2@ssafy.com'),
('ssafy3', 'ssafy3', '전민정', 'ssafy3@ssafy.com');


INSERT INTO Review(title,  writerId, content, regDate, youtubeId, viewCnt)
VALUES ("좋아요", "ssafy1", "좋아요", "2023-10-13", 'gMaB-fG4u4g', 0),
("멋져요", "ssafy2", "멋져요", "2023-10-13", 'gMaB-fG4u4g', 0);

select * from video;
select * from mem;
select * from review;